// Pouzivatelsky Vystup
// Pomocou dvojit�ch �vodzoviek m��eme vklada� premenn�
def menoPouzivatela = "Adam Sangala";
println("Prave nastupil $menoPouzivatela na podium");

// To ist� m��ete urobi� s printf
printf("Prave nastupil %s na podium \n", menoPouzivatela);

// Pou�ite viacero hodn�t
// %d digit
// %f
printf("\n\n%-10s %d %.2f %10s \n", ['Heslo', 1000, 1000.1234, 'Nieco']);



